package com.BMS_Hibernate.dao;

public interface BMS_Dao {
	public void createAccount();
	public void depositMoney();
	public void withdrawMoney();
	public void showAccount();
	public void updateAccount();
	public void deleteAccount();
	
}
